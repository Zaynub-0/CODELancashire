window.addEventListener('load', function(event){
    printText();
    printInputText();
    sendContactDetails();
});

function printText(){
    const button = document.getElementById('click-btn');
    button.addEventListener('click', () => {
        const login = document.getElementById('login');
        const company = document.getElementById('company');
        const website = document.getElementById('website');
        fetch("https://api.com")
        .then((response) => response.json())
        .then((data) => {
            console.log("data we received", data);
            login.innerHTML = data.login;
            website.innerHTML = data.blog;
            company.innerHTML = data.company;
        });
    });
}

function printInputText(){
    const fnInput = document.getElementById('fn-input');
    const spanText = document.getElementById('input-text');

    fnInput.addEventListener('input', (event) => {
        const inputValue = fnInput.value;
        spanText.innerHTML = inputValue;
    });
}

function sendContactDetails(){
    const form = document.getElementById('contact-form');
    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        console.log("formData", data);

        // You can also add additional code here to send data to a server or display a success message.
    });
}
